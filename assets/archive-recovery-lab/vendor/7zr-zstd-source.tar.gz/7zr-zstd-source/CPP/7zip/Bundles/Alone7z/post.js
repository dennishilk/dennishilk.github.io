Module.FS = FS; Module.callMain = callMain;
// Library calls must return status instead of changing the host Node process exit status.
quit_ = (_status, error) => { throw error; };
